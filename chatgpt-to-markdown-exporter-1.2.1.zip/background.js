
// background.js (MV3 service worker) — v1.2.1
function isChatGPTUrl(url) {
  return /^https?:\/\/(chatgpt\.com|chat\.openai\.com)\//i.test(url || "");
}

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab || !tab.id || !isChatGPTUrl(tab.url)) return;
  try {
    await chrome.tabs.sendMessage(tab.id, { type: "EXPORT_MARKDOWN" });
  } catch (e) {
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
      await chrome.tabs.sendMessage(tab.id, { type: "EXPORT_MARKDOWN" });
    } catch (err) {
      console.error("Failed to trigger export:", err);
    }
  }
});
