
async function load() {
  const defaults = {
    highlightStyle: "doubleEquals",
    includeMeta: "yes",
    roleHeadings: "yes",
    imageMode: "keep",
    filenamePattern: "{title}-{yyyy}-{mm}-{dd}.md"
  };
  const cfg = Object.assign(defaults, await chrome.storage.local.get(defaults));
  for (const [k,v] of Object.entries(cfg)) {
    const el = document.getElementById(k);
    if (el) el.value = v;
  }
}
async function save() {
  const cfg = {
    highlightStyle: document.getElementById("highlightStyle").value,
    includeMeta: document.getElementById("includeMeta").value,
    roleHeadings: document.getElementById("roleHeadings").value,
    imageMode: document.getElementById("imageMode").value,
    filenamePattern: document.getElementById("filenamePattern").value.trim() || "{title}-{yyyy}-{mm}-{dd}.md"
  };
  await chrome.storage.local.set(cfg);
  const status = document.getElementById("status");
  status.textContent = "Saved.";
  setTimeout(()=>status.textContent="", 1500);
}
document.getElementById("saveBtn").addEventListener("click", save);
load();
