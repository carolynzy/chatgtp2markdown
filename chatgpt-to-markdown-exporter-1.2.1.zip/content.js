
// content.js — v1.2.1 (storage.local, no activeTab)
(function() {
  const BTN_HOST_ID = "gpt-md-exporter-btn"; // host element id (Shadow DOM)
  let shadowRootRef = null;

  // Options defaults + validation
  const DEFAULTS = {
    highlightStyle: "doubleEquals",
    includeMeta: "yes",
    roleHeadings: "yes",
    imageMode: "keep",
    filenamePattern: "{title}-{yyyy}-{mm}-{dd}.md"
  };
  const ALLOWED = {
    highlightStyle: new Set(["doubleEquals", "htmlMark"]),
    includeMeta: new Set(["yes", "no"]),
    roleHeadings: new Set(["yes", "no"]),
    imageMode: new Set(["keep", "links", "omit"])
  };
  function sanitizeOptions(o) {
    const out = Object.assign({}, DEFAULTS, o || {});
    if (!ALLOWED.highlightStyle.has(out.highlightStyle)) out.highlightStyle = DEFAULTS.highlightStyle;
    if (!ALLOWED.includeMeta.has(out.includeMeta)) out.includeMeta = DEFAULTS.includeMeta;
    if (!ALLOWED.roleHeadings.has(out.roleHeadings)) out.roleHeadings = DEFAULTS.roleHeadings;
    if (!ALLOWED.imageMode.has(out.imageMode)) out.imageMode = DEFAULTS.imageMode;
    if (typeof out.filenamePattern !== "string" || !out.filenamePattern.trim()) {
      out.filenamePattern = DEFAULTS.filenamePattern;
    }
    return out;
  }

  // Inject floating button in Shadow DOM
  function injectButton() {
    if (document.getElementById(BTN_HOST_ID)) return;
    const host = document.createElement("div");
    host.id = BTN_HOST_ID;
    const shadow = host.attachShadow({ mode: "open" });
    shadowRootRef = shadow;

    const style = document.createElement("style");
    style.textContent = `
      :host { all: initial; }
      button {
        position: fixed; right: 16px; bottom: 16px;
        z-index: 2147483647;
        padding: 10px 14px;
        border-radius: 9999px;
        border: 1px solid rgba(0,0,0,.1);
        background: #fff;
        box-shadow: 0 8px 20px rgba(0,0,0,.15);
        font-size: 14px; line-height: 1; cursor: pointer;
      }
      button:hover { box-shadow: 0 10px 24px rgba(0,0,0,.18); }
      #toast {
        position: fixed; bottom: 70px; right: 16px; z-index: 2147483647;
        padding: 10px 12px; background: #111; color: #fff;
        border-radius: 8px; font-size: 13px; display: none;
      }
    `;

    const btn = document.createElement("button");
    btn.textContent = "Export MD";
    btn.addEventListener("click", runExport);

    const toast = document.createElement("div");
    toast.id = "toast";

    shadow.append(style, btn, toast);
    document.documentElement.appendChild(host);
  }

  function showToast(msg) {
    const toast = shadowRootRef && shadowRootRef.getElementById("toast");
    if (!toast) return;
    toast.textContent = msg;
    toast.style.display = "block";
    clearTimeout(showToast._t);
    showToast._t = setTimeout(()=>{ toast.style.display = "none"; }, 2500);
  }

  // Listen for toolbar icon click
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === "EXPORT_MARKDOWN") {
      runExport();
      sendResponse({ ok: true });
    }
  });

  // Observe to re-inject if DOM is rebuilt
  const ro = new ResizeObserver(() => injectButton());
  ro.observe(document.documentElement);
  injectButton();
  window.addEventListener("beforeunload", () => ro.disconnect());

  // ---- Export core ----
  async function runExport() {
    const stored = await chrome.storage.local.get(DEFAULTS);
    const options = sanitizeOptions(stored);

    const { title, messages } = collectConversation();
    const md = buildMarkdown(title, messages, options);
    const filename = makeFilename(options.filenamePattern, title);

    downloadText(filename, md);
    showToast("Markdown exported.");
  }

  function makeFilename(pattern, title) {
    const d = new Date();
    const pad = (n) => String(n).padStart(2, "0");
    const base = pattern
      .replace("{title}", sanitizeFilename(title || "ChatGPT Conversation"))
      .replace("{yyyy}", d.getFullYear())
      .replace("{mm}", pad(d.getMonth()+1))
      .replace("{dd}", pad(d.getDate()))
      .replace("{hh}", pad(d.getHours()))
      .replace("{min}", pad(d.getMinutes()));
    return base.slice(0, 200);
  }

  function sanitizeFilename(name) {
    const safe = name.replace(/[\\/:*?"<>|]+/g, " ").replace(/\s+/g, " ").trim();
    return safe.slice(0, 150);
  }

  // Collect messages using robust-ish selectors
  function collectConversation() {
    const docTitle = document.title.replace(/\s*\|\s*ChatGPT.*/i,"").trim();
    const nodes = Array.from(document.querySelectorAll("[data-message-author-role]"));
    const messages = nodes.map(node => {
      const role = node.getAttribute("data-message-author-role") || "assistant";
      const content = node.querySelector(".markdown, .prose, [data-message-content], .whitespace-pre-wrap, article, section") || node;
      return { role, html: content.innerHTML };
    }).filter(m => m.html && m.html.trim() !== "");
    return { title: docTitle || "ChatGPT Conversation", messages };
  }

  function yamlEscape(s) {
    return String(s)
      .replace(/\\/g, "\\\\")
      .replace(/"/g, '\\"')
      .replace(/\r?\n/g, " ");
  }

  function buildMarkdown(title, messages, options) {
    const parts = [];
    if (options.includeMeta === "yes") {
      const dt = new Date().toISOString();
      parts.push([
        "---",
        `title: "${yamlEscape(title)}"`,
        `exported_at: "${dt}"`,
        "source: chatgpt.com",
        "---",
        ""
      ].join("\n"));
    }

    for (const m of messages) {
      if (options.roleHeadings === "yes") {
        const label = m.role === "user" ? "User" : (m.role === "assistant" ? "Assistant" : m.role);
        parts.push(`### ${label}\n`);
      }
      parts.push(htmlToMarkdown(m.html, options));
      parts.push("\n");
      parts.push("---");
      parts.push("\n");
    }
    return parts.join("\n").replace(/\n{3,}/g, "\n\n");
  }

  function htmlToMarkdown(html, options) {
    const div = document.createElement("div");
    div.innerHTML = html;
    processHighlights(div, options);
    return nodeToMd(div, options).trim();
  }

  function processHighlights(root, options) {
    if (options.highlightStyle !== "doubleEquals") return;
    const marks = root.querySelectorAll("mark, span[style*='background']");
    marks.forEach(el => el.setAttribute("data-md-highlight", "true"));
  }

  // URL sanitizer for links and images
  function sanitizeUrl(href, allowDataImages = false) {
    try {
      const u = new URL(href, location.origin);
      const safeProtocols = new Set(["http:", "https:", "mailto:", "tel:", "blob:"]);
      if (allowDataImages) safeProtocols.add("data:");
      if (!safeProtocols.has(u.protocol)) return "";
      return u.href;
    } catch {
      return "";
    }
  }

  function escapeMdBase(s) {
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/\\/g, "\\\\")
      .replace(/([*_`~])/g, "\\$1")
      .replace(/([\[\]\(\)])/g, "\\$1");
  }

  function nodeToMd(node, options, ctx = { listIndent: 0, inCode: false }) {
    if (node.nodeType === Node.TEXT_NODE) {
      const raw = node.nodeValue;
      if (!raw) return "";
      if (ctx.inCode) {
        return raw; // preserve exactly in code contexts
      } else {
        const normalized = raw.replace(/\s+/g, " ");
        return escapeMdBase(normalized);
      }
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return "";

    const tag = node.tagName.toLowerCase();
    const isBlock = /^(p|div|section|article|h[1-6]|pre|blockquote|ul|ol|li|table|thead|tbody|tr|hr)$/i.test(tag);
    let out = "";

    function mdChildren(extraCtx) {
      const nextCtx = Object.assign({}, ctx, extraCtx || {});
      return Array.from(node.childNodes).map(n => nodeToMd(n, options, nextCtx)).join("");
    }

    switch (tag) {
      case "br":
        out = "  \n";
        break;
      case "strong":
      case "b":
        out = `**${mdChildren().trim()}**`;
        break;
      case "em":
      case "i":
        out = `*${mdChildren().trim()}*`;
        break;
      case "u":
        out = mdChildren();
        break;
      case "code":
        if (node.parentElement && node.parentElement.tagName.toLowerCase() === "pre") {
          out = mdChildren({ inCode: true });
        } else {
          let text = "";
          node.childNodes.forEach(n => { text += nodeToMd(n, options, { listIndent: ctx.listIndent, inCode: true }); });
          text = text.replace(/`/g, "\\`");
          out = "`" + text + "`";
        }
        break;
      case "pre": {
        const codeEl = node.querySelector("code") || node;
        const langAttr = codeEl.getAttribute("data-language");
        const className = (codeEl.getAttribute("class") || "");
        const m = className.match(/language-([a-z0-9+#-]+)/i) || (langAttr ? [null, langAttr] : null);
        const lang = m ? m[1] : "";
        let content = (codeEl.textContent || "").replace(/\r\n/g, "\n");
        const fence = content.includes("```") ? "~~~" : "```";
        out = `\n${fence}${lang ? (lang === "none" ? "" : lang) : ""}\n${content}\n${fence}\n`;
        break;
      }
      case "h1":
      case "h2":
      case "h3":
      case "h4":
      case "h5":
      case "h6": {
        const level = parseInt(tag[1], 10);
        out = "\n" + "#".repeat(level) + " " + mdChildren().trim() + "\n";
        break;
      }
      case "p":
      case "div":
      case "section":
      case "article":
        out = mdChildren().trim() + "\n\n";
        break;
      case "blockquote": {
        const inner = mdChildren().trim();
        out = inner.split("\n").map(l => l ? `> ${l}` : ">").join("\n") + "\n\n";
        break;
      }
      case "ol": {
        const start = parseInt(node.getAttribute("start") || "1", 10);
        const items = Array.from(node.children).filter(c => c.tagName && c.tagName.toLowerCase() === "li");
        out = "\n" + items.map((li, idx) => {
          const marker = `${(start + idx)}. `;
          const liMd = nodeToMd(li, options, { listIndent: (ctx.listIndent||0) + 1, inCode: false }).trim();
          return "  ".repeat(ctx.listIndent) + marker + liMd.replace(/\n/g, "\n" + "  ".repeat(ctx.listIndent + 1));
        }).join("\n") + "\n\n";
        break;
      }
      case "ul": {
        const items = Array.from(node.children).filter(c => c.tagName && c.tagName.toLowerCase() === "li");
        out = "\n" + items.map((li) => {
          const marker = "- ";
          const liMd = nodeToMd(li, options, { listIndent: (ctx.listIndent||0) + 1, inCode: false }).trim();
          return "  ".repeat(ctx.listIndent) + marker + liMd.replace(/\n/g, "\n" + "  ".repeat(ctx.listIndent + 1));
        }).join("\n") + "\n\n";
        break;
      }
      case "li":
        out = mdChildren();
        break;
      case "a": {
        const rawHref = node.getAttribute("href") || "";
        const href = sanitizeUrl(rawHref, false);
        const text = (mdChildren().trim() || href).replace(/([\[\]])/g, "\\$1");
        const safeHref = (href || "").replace(/[()]/g, "\\$&");
        out = href ? `[${text}](${safeHref})` : text;
        break;
      }
      case "img": {
        const alt = (node.getAttribute("alt") || "").replace(/([\[\]])/g, "\\$1");
        const rawSrc = node.getAttribute("src") || "";
        const src = sanitizeUrl(rawSrc, options.imageMode === "keep");
        if (options.imageMode === "keep") {
          out = src ? `![${alt}](${src.replace(/[()]/g, "\\$&")})` : (alt ? `![${alt}]()` : "");
        } else if (options.imageMode === "links") {
          out = src ? `[${alt || "image"}](${src.replace(/[()]/g, "\\$&")})` : (alt || "");
        } else {
          out = "";
        }
        break;
      }
      case "hr":
        out = "\n---\n";
        break;
      case "table":
        out = tableToMd(node) + "\n\n";
        break;
      case "mark":
      case "span": {
        if (node.getAttribute("data-md-highlight") === "true") {
          const inner = mdChildren();
          out = (options.highlightStyle === "doubleEquals") ? `==${inner}==` : `<mark>${inner}</mark>`;
        } else {
          out = mdChildren();
        }
        break;
      }
      default:
        out = mdChildren();
    }

    if (isBlock && !/\n$/.test(out)) out += "\n";
    return out;
  }

  function tableToMd(table) {
    const rows = Array.from(table.querySelectorAll("tr"));
    if (!rows.length) return "";
    function cells(tr, sel) {
      return Array.from(tr.querySelectorAll(sel)).map(td => {
        const txt = td.innerText.trim().replace(/\|/g, "\\|").replace(/\n/g, "<br>");
        return txt;
      });
    }
    let header = [];
    let body = [];
    if (table.querySelector("thead")) {
      const theadRow = table.querySelector("thead tr") || rows[0];
      header = cells(theadRow, "th,td");
      body = rows.slice(1).map(r => cells(r, "td"));
    } else {
      header = cells(rows[0], "th,td");
      body = rows.slice(1).map(r => cells(r, "td"));
    }
    const line = "|" + header.join("|") + "|\n|" + header.map(()=> "---").join("|") + "|";
    const rest = body.map(r => "|" + r.join("|") + "|").join("\n");
    return line + (rest ? "\n" + rest : "");
  }

  function downloadText(filename, text) {
    const blob = new Blob([text], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }
})();
