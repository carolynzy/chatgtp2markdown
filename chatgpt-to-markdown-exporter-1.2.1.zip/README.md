
# ChatGPT → Markdown Exporter (Chrome Extension)

Export ChatGPT conversations to **Markdown**, preserving **code blocks** and **highlights**. No remote code. No data collection.

## Changelog

**1.2.1** — Privacy alignment
- Switched settings to `chrome.storage.local` (no cloud sync).
- Removed `activeTab` permission for least privilege.

**1.2.0** — Security & robustness
- URL sanitizer for links/images; escape `[]()`; background guard to ChatGPT hosts; CSP; Shadow DOM; safer YAML/filename; better code block detection; ordered list `start`; table `<br>` handling.

**1.1.0** — Robustness improvements
- Escape `<`, `>`, `&` in plain text; preserve code verbatim.

**1.0.0** — Initial release.
